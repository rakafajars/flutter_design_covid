# Design Covid

Belajar Design dari youtube 
https://www.youtube.com/watch?v=yG3WiFu2aUE&t=1s
