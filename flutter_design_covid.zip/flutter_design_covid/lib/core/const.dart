import 'package:flutter/material.dart';

class AppColors {
  static final Color backGroundColor = Color(0XFFefedf2);
  static final Color mainColor = Color(0XFF8d12fe);  
}
